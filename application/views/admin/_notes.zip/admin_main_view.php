<?php


// home main_view

$this->load->view('admin/header_view');
$this->load->view($main_view);
$this->load->view('admin/footer_view');

